<!-- resources/views/emails/reset-password.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <h2>Afiliado</h2>
    <p>
        Usuário quer ser afiliado. Entre em contato pelo email: {{ $email }}
    </p>
</body>
</html>
